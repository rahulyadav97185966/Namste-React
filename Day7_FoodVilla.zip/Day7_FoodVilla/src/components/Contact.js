const Contact = () => {
  return (
    <div>
      <h1>Contact Us Page</h1>
      <p>Contact us page nothin special da.....</p>
    </div>
  );
};
export default Contact;
